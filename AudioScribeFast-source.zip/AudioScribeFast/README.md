# AudioScribe Fast

Android app nativa per selezionare un video dalla Galleria, estrarne l'audio e trascriverlo rapidamente in italiano.

## Funzioni
- Selezione video tramite Android Photo Picker (nessun permesso galleria richiesto)
- Estrazione audio M4A senza ricodifica, quindi molto rapida
- Trascrizione rapida con Groq `whisper-large-v3-turbo`
- Suddivisione automatica in blocchi da 8 minuti e massimo 2 upload contemporanei
- Lingua impostata su italiano (`it`)
- Testo modificabile, copiabile e salvabile in TXT
- Chiave Groq cifrata con Android Keystore
- Icona personalizzata AudioScribe (nessun robottino Android)

## Perché è più veloce
La versione Fast non esegue il modello Whisper pesante sul telefono. Estrae solo la traccia audio compressa e la invia a Groq. I blocchi vengono elaborati in parallelo (massimo 2 alla volta).

## Privacy
Per la modalità veloce, l'audio viene inviato all'API Groq. La chiave API non è inserita nel repository: viene digitata nell'app e salvata cifrata sul dispositivo.

## Ottenere una Groq API key
1. Crea/accedi al tuo account Groq Console.
2. Genera una API key.
3. Apri AudioScribe Fast, incollala nel campo `Groq API key` la prima volta.

Non inserire mai la chiave direttamente nei file del repository.

## Build con GitHub Actions
1. Crea un repository GitHub vuoto.
2. Carica tutto il contenuto di questa cartella nella root del repository.
3. Fai commit sul branch `main`.
4. Apri la scheda **Actions** → **Build Android APK**.
5. Al termine, scarica l'artifact `AudioScribeFast-debug-apk`.
6. Dentro lo ZIP dell'artifact trovi `app-debug.apk`.

Il workflow parte anche automaticamente a ogni push su `main`.

## Requisiti
- Android 8.0+ (minSdk 26)
- Connessione Internet per la trascrizione veloce
- Groq API key

## Note tecniche
- compileSdk 35
- targetSdk 35
- Kotlin / Android Views
- OkHttp per l'API
- Android MediaExtractor + MediaMuxer per l'audio
