package com.vilma.audioscribefast

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var apiKeyInput: EditText
    private lateinit var selectVideoButton: Button
    private lateinit var extractAudioButton: Button
    private lateinit var transcribeButton: Button
    private lateinit var copyButton: Button
    private lateinit var saveButton: Button
    private lateinit var videoInfo: TextView
    private lateinit var statusText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var transcriptInput: EditText

    private var selectedVideo: Uri? = null
    private var pendingAudioDestination: Uri? = null
    private val securePrefs by lazy { SecurePrefs(this) }
    private val transcriber = GroqTranscriber()

    private val videoPicker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            selectedVideo = uri
            updateSelectedVideo(uri)
            extractAudioButton.isEnabled = true
            transcribeButton.isEnabled = true
        }
    }

    private val saveTextLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            runCatching {
                contentResolver.openOutputStream(uri)?.use { stream ->
                    stream.write(transcriptInput.text.toString().toByteArray(Charsets.UTF_8))
                }
            }.onSuccess {
                toast("Testo salvato")
            }.onFailure {
                toast("Errore nel salvataggio: ${it.message}")
            }
        }
    }

    private val saveAudioLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("audio/mp4")) { uri ->
        if (uri != null) {
            pendingAudioDestination = uri
            extractAudioTo(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        apiKeyInput = findViewById(R.id.apiKeyInput)
        selectVideoButton = findViewById(R.id.selectVideoButton)
        extractAudioButton = findViewById(R.id.extractAudioButton)
        transcribeButton = findViewById(R.id.transcribeButton)
        copyButton = findViewById(R.id.copyButton)
        saveButton = findViewById(R.id.saveButton)
        videoInfo = findViewById(R.id.videoInfo)
        statusText = findViewById(R.id.statusText)
        progress = findViewById(R.id.progress)
        transcriptInput = findViewById(R.id.transcriptInput)

        apiKeyInput.setText(securePrefs.loadApiKey())

        selectVideoButton.setOnClickListener {
            videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
        }

        extractAudioButton.setOnClickListener {
            if (selectedVideo == null) return@setOnClickListener
            saveAudioLauncher.launch("audio_estratto.m4a")
        }

        transcribeButton.setOnClickListener { startTranscription() }

        copyButton.setOnClickListener {
            val text = transcriptInput.text.toString()
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Trascrizione", text))
            toast("Testo copiato")
        }

        saveButton.setOnClickListener {
            saveTextLauncher.launch("trascrizione.txt")
        }
    }

    override fun onPause() {
        super.onPause()
        securePrefs.saveApiKey(apiKeyInput.text?.toString()?.trim().orEmpty())
    }

    private fun startTranscription() {
        val uri = selectedVideo ?: return
        val apiKey = apiKeyInput.text?.toString()?.trim().orEmpty()
        if (apiKey.isBlank()) {
            apiKeyInput.error = "Inserisci una Groq API key"
            return
        }
        securePrefs.saveApiKey(apiKey)

        setBusy(true, "Estraggo e divido l'audio…")
        lifecycleScope.launch {
            val result = runCatching {
                val sessionDir = withContext(Dispatchers.IO) {
                    File(cacheDir, "transcription_${System.currentTimeMillis()}").apply { mkdirs() }
                }
                val chunks = withContext(Dispatchers.IO) {
                    AudioExtractor.extractChunks(this@MainActivity, uri, sessionDir)
                }

                statusText.text = if (chunks.size == 1) {
                    "Invio 1 blocco audio…"
                } else {
                    "Invio ${chunks.size} blocchi audio in parallelo…"
                }

                val semaphore = Semaphore(2)
                val parts = coroutineScope {
                    chunks.map { file ->
                        async(Dispatchers.IO) {
                            semaphore.withPermit { transcriber.transcribe(file, apiKey) }
                        }
                    }.awaitAll()
                }
                withContext(Dispatchers.IO) { sessionDir.deleteRecursively() }
                parts.filter { it.isNotBlank() }.joinToString("\n\n")
            }

            result.onSuccess { text ->
                transcriptInput.setText(text)
                setBusy(false, "Trascrizione completata")
            }.onFailure { error ->
                setBusy(false, "Errore")
                toast(error.message ?: "Errore durante la trascrizione")
            }
        }
    }

    private fun extractAudioTo(destination: Uri) {
        val source = selectedVideo ?: return
        setBusy(true, "Estraggo l'audio…")
        lifecycleScope.launch {
            val result = runCatching {
                val temp = File(cacheDir, "audio_${System.currentTimeMillis()}.m4a")
                withContext(Dispatchers.IO) {
                    AudioExtractor.extractWhole(this@MainActivity, source, temp)
                    contentResolver.openOutputStream(destination)?.use { output ->
                        temp.inputStream().use { input -> input.copyTo(output) }
                    } ?: error("Impossibile aprire il file di destinazione")
                    temp.delete()
                }
            }
            result.onSuccess {
                setBusy(false, "Audio estratto e salvato")
                toast("Audio salvato")
            }.onFailure {
                setBusy(false, "Errore")
                toast("Errore estrazione audio: ${it.message}")
            }
            pendingAudioDestination = null
        }
    }

    private fun updateSelectedVideo(uri: Uri) {
        val name = queryDisplayName(uri) ?: "Video selezionato"
        val size = querySize(uri)
        val durationMs = runCatching {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(this, uri)
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            } finally {
                retriever.release()
            }
        }.getOrDefault(0L)

        val duration = if (durationMs > 0) {
            val totalSec = durationMs / 1000
            String.format(Locale.ITALY, "%d:%02d", totalSec / 60, totalSec % 60)
        } else "durata n/d"
        val sizeText = if (size > 0) formatBytes(size) else "dimensione n/d"
        videoInfo.text = "$name • $duration • $sizeText"
    }

    private fun queryDisplayName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) return cursor.getString(0)
        }
        return null
    }

    private fun querySize(uri: Uri): Long {
        contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst() && !cursor.isNull(0)) return cursor.getLong(0)
        }
        return -1L
    }

    private fun formatBytes(bytes: Long): String {
        val mb = bytes / (1024.0 * 1024.0)
        return String.format(Locale.ITALY, "%.1f MB", mb)
    }

    private fun setBusy(busy: Boolean, status: String) {
        progress.visibility = if (busy) View.VISIBLE else View.GONE
        statusText.text = status
        selectVideoButton.isEnabled = !busy
        extractAudioButton.isEnabled = !busy && selectedVideo != null
        transcribeButton.isEnabled = !busy && selectedVideo != null
        copyButton.isEnabled = !busy
        saveButton.isEnabled = !busy
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
