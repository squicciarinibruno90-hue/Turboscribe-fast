package com.vilma.audioscribefast

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.min

object AudioExtractor {
    private const val DEFAULT_BUFFER = 1 * 1024 * 1024
    private const val CHUNK_US = 8L * 60L * 1_000_000L // 8 minutes

    data class AudioInfo(val durationUs: Long, val mime: String)

    fun inspect(context: Context, uri: Uri): AudioInfo {
        val extractor = MediaExtractor()
        return try {
            extractor.setDataSource(context, uri, null)
            val index = findAudioTrack(extractor)
            require(index >= 0) { "Il video non contiene una traccia audio." }
            val format = extractor.getTrackFormat(index)
            val durationUs = if (format.containsKey(MediaFormat.KEY_DURATION)) {
                format.getLong(MediaFormat.KEY_DURATION)
            } else 0L
            val mime = format.getString(MediaFormat.KEY_MIME) ?: "audio/mp4a-latm"
            AudioInfo(durationUs, mime)
        } finally {
            extractor.release()
        }
    }

    fun extractWhole(context: Context, uri: Uri, output: File): File {
        return extractRange(context, uri, output, 0L, Long.MAX_VALUE)
    }

    fun extractChunks(context: Context, uri: Uri, outputDir: File): List<File> {
        val info = inspect(context, uri)
        if (info.durationUs <= 0L || info.durationUs <= CHUNK_US) {
            return listOf(extractRange(context, uri, File(outputDir, "chunk_000.m4a"), 0L, Long.MAX_VALUE))
        }

        val files = mutableListOf<File>()
        var startUs = 0L
        var index = 0
        while (startUs < info.durationUs) {
            val endUs = min(startUs + CHUNK_US, info.durationUs)
            val file = File(outputDir, "chunk_${index.toString().padStart(3, '0')}.m4a")
            files += extractRange(context, uri, file, startUs, endUs)
            startUs = endUs
            index++
        }
        return files
    }

    private fun extractRange(
        context: Context,
        uri: Uri,
        output: File,
        startUs: Long,
        endUs: Long
    ): File {
        if (output.exists()) output.delete()
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        try {
            extractor.setDataSource(context, uri, null)
            val audioTrack = findAudioTrack(extractor)
            require(audioTrack >= 0) { "Il video non contiene una traccia audio." }
            extractor.selectTrack(audioTrack)
            val format = extractor.getTrackFormat(audioTrack)

            val maxInput = if (format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE).coerceAtLeast(64 * 1024)
            } else DEFAULT_BUFFER
            val buffer = ByteBuffer.allocateDirect(maxInput.coerceAtMost(4 * 1024 * 1024))
            val info = MediaCodec.BufferInfo()

            muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val muxTrack = muxer.addTrack(format)
            muxer.start()

            if (startUs > 0L) extractor.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

            var firstPts = -1L
            while (true) {
                val sampleTime = extractor.sampleTime
                if (sampleTime < 0L || sampleTime >= endUs) break
                if (sampleTime < startUs) {
                    extractor.advance()
                    continue
                }

                buffer.clear()
                val size = extractor.readSampleData(buffer, 0)
                if (size < 0) break
                if (firstPts < 0L) firstPts = sampleTime

                info.offset = 0
                info.size = size
                info.presentationTimeUs = (sampleTime - firstPts).coerceAtLeast(0L)
                info.flags = extractor.sampleFlags
                muxer.writeSampleData(muxTrack, buffer, info)
                extractor.advance()
            }
        } finally {
            runCatching { muxer?.stop() }
            runCatching { muxer?.release() }
            extractor.release()
        }
        require(output.exists() && output.length() > 0L) { "Impossibile estrarre l'audio." }
        return output
    }

    private fun findAudioTrack(extractor: MediaExtractor): Int {
        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/")) return i
        }
        return -1
    }
}
